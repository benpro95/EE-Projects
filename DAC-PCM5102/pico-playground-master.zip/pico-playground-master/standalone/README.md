Directory of standalone projects; i.e. they are not included in the main build.
You should do a cmake build from within them